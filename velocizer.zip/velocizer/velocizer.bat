@echo off
title VELOCIZER
powercfg -h off
bcdebit /deletevalue useplatformclock
bcdebit /set disabledynamictick yes
cd /d "%~dp0" && ( if exist "%temp%\getadmin.vbs" del "%temp%\getadmin.vbs" ) && fsutil dirty query %systemdrive% 1>nul 2>nul || (  echo Set UAC = CreateObject^("Shell.Application"^) : UAC.ShellExecute "cmd.exe", "/k cd ""%~sdp0"" && %~s0 %params%", "", "runas", 1 >> "%temp%\getadmin.vbs" && "%temp%\getadmin.vbs" && exit /B )
bcdedit /set useplatformtick yes
bcdedit /timeout 0
netsh interface tcp set global autotuninglevel=normal
netsh winsock reset
netsh int ip reset
netsh interface teredo set state disabled
netsh interface 6to4 set state disabled
netsh winsock reset
netsh int isatap set state disable
netsh int ip set global taskoffload=disabled
netsh int ip set global neighborcachelimit=8192
shift /0
mode 128,33
ipconfig /flushdns
rd /s /q c:\windows\temp
md c:\windows\temp
powercfg -duplicatescheme e9a42b02-d5df-448d-aa00-03f14749eb61
del /q /s /f %temp%\*.*
Reg.exe add "HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile" /v "SystemResponsiveness" /t REG_DWORD /d "0" /f
rd /s /q C:\$Recycle.Bin
cls
pause
shutdown /r /t 0